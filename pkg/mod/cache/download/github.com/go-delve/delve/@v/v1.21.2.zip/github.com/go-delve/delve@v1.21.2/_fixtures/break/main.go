package main

func asmBrk()

func main() {
	asmBrk()
}
