// Copyright (C) 2017 ScyllaDB
// Use of this source code is governed by a ALv2-style
// license that can be found in the LICENSE file.

// Package gocqlxtest provides test helpers for integration tests.
package gocqlxtest
