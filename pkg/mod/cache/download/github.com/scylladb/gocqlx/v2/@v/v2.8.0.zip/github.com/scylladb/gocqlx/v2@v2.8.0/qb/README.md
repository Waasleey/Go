# GoCQLX Query Builder

Package `qb` provides CQL query builders. The builders create CQL statement
and a list of named parameters that can later be bound using `gocqlx`.

The following CQL commands are supported: `SELECT`, `INSERT`, `UPDATE`, `DELETE` and  `BATCH`. 
